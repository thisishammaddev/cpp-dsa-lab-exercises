﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AbstractionPractice
{
    //SIMPLE ABSTRACTION
    //class Employee
    //{
    //    public int EmpId;
    //    public string EmpName;
    //    public double GrossPay;
    //    double TaxDeduction = 0.1D;
    //    double EmpNetSal;

    //    public Employee(int Eid, string Ename, double EgrossP) 
    //    {
    //        this.EmpId = Eid;
    //        this.EmpName = Ename;
    //        this.GrossPay = EgrossP;
    //    }
    //    //Abstraction = hiding the uneccessary details from real world
    //    void CalcSal()
    //    {
    //        if (GrossPay >= 30000)
    //        {
    //            EmpNetSal = GrossPay - (TaxDeduction * GrossPay);
    //            Console.WriteLine("Your Net Salary: " + EmpNetSal);
    //        }
    //        else
    //        {
    //            Console.WriteLine("Your Salary: " + GrossPay);
    //        }
    //    }
    //    public void ShowEmpDetails()
    //    {
    //        Console.WriteLine("Employee id: " + EmpId);
    //        Console.WriteLine("Employee Name: " + EmpName);
    //        this.CalcSal();
    //    }
    //}



    //Abstract Methods and Classes
    //abstract class Person
    //{
    //    public string Fname;
    //    public string Lname;
    //    public int Age;
    //    public string Phone;

    //    public abstract void ShowDetails();
    //}
    //class Student : Person
    //{
    //    public int roll;
    //    public int fees;

    //    public override void ShowDetails()
    //    {
    //        string name = this.Fname + " " + this.Lname;
    //        Console.WriteLine("Student Name is: " + name);
    //        Console.WriteLine("Student age is: " + this.Age);
    //        Console.WriteLine("Student Roll number is: " + this.roll);
    //        Console.WriteLine("Student fees is: " + this.fees);
    //        Console.WriteLine("Studnet Phone is: " + this.Phone);
    //    }
    //}
    //class Teacher : Person
    //{
    //    public string qul;
    //    public int salary;
    //    public override void ShowDetails()
    //    {
    //        string name = this.Fname + " " + this.Lname;
    //        Console.WriteLine("Teacher Name is: " + name);
    //        Console.WriteLine("Teacher Age is: " + this.Age);
    //        Console.WriteLine("Teacher Phone is: " + this.Phone);
    //        Console.WriteLine("Teacher Qualifications: " + this.qul);
    //        Console.WriteLine("Teacher salary is: " + this.salary);
    //    }
    //}

    //Abstract Properties
    abstract class Person
    {
        public abstract string Name { get; set; }
        public abstract int Id { get; set; }
    }
    class Student : Person
    {
        int StudentId;
        string StudentName;
        public override int Id
        {
            set { this.StudentId = value; }
            get { return StudentId; }
        }
        public override string Name
        {
            set { this.StudentName = value; }
            get { return StudentName; }

        }
        internal class Program
        {
            static void Main(string[] args)
            {
                //SIMPLE ABSTRACTION
                //Employee emp = new Employee(123, "Numan", 55000);
                //emp.ShowEmpDetails();

                //Abstract Class and Methods
                //Console.WriteLine("---------Student's Info---------");
                //Student s1 = new Student();
                //s1.Fname = "Numan";
                //s1.Lname = "Nadeem";
                //s1.Age = 19;
                //s1.roll = 1;
                //s1.Phone = "03553829742";
                //s1.fees = 4000;
                //s1.ShowDetails();
                ////for teacher
                //Console.WriteLine("---------Teacher's Info---------");
                //Teacher t1 = new Teacher();
                //t1.Fname = "Sajjad";
                //t1.Lname = "Ali";
                //t1.Age = 34;
                //t1.salary = 50000;
                //t1.Phone = "03241234576";
                //t1.qul = "Graduation in Information & Technology";
                //t1.ShowDetails();



                //Abstract Properties
                Student st1 = new Student();
                st1.Id = 123;
                st1.Name = "Numan";
                Console.WriteLine("Student Id: " + st1.Id);
                Console.WriteLine("Student Name is: " + st1.Name);
                Console.ReadLine();
            }
        }
    }
}
