﻿namespace lblProject
{
    partial class LabelMsg
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            textBox1 = new TextBox();
            textBox2 = new TextBox();
            btnClick = new Button();
            lblMsg = new Label();
            SuspendLayout();
            // 
            // textBox1
            // 
            textBox1.Location = new Point(79, 43);
            textBox1.Multiline = true;
            textBox1.Name = "textBox1";
            textBox1.Size = new Size(128, 31);
            textBox1.TabIndex = 0;
            textBox1.TextChanged += textBox1_TextChanged;
            // 
            // textBox2
            // 
            textBox2.Location = new Point(274, 43);
            textBox2.Multiline = true;
            textBox2.Name = "textBox2";
            textBox2.Size = new Size(128, 31);
            textBox2.TabIndex = 0;
            textBox2.TextChanged += textBox2_TextChanged;
            // 
            // btnClick
            // 
            btnClick.Location = new Point(169, 104);
            btnClick.Name = "btnClick";
            btnClick.Size = new Size(128, 25);
            btnClick.TabIndex = 1;
            btnClick.Text = "Click it";
            btnClick.UseVisualStyleBackColor = true;
            btnClick.Click += btnClick_Click;
            // 
            // lblMsg
            // 
            lblMsg.AutoSize = true;
            lblMsg.Location = new Point(126, 170);
            lblMsg.Name = "lblMsg";
            lblMsg.Size = new Size(0, 15);
            lblMsg.TabIndex = 2;
            lblMsg.Visible = false;
            lblMsg.Click += lblMsg_Click;
            // 
            // LabelMsg
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(500, 302);
            Controls.Add(lblMsg);
            Controls.Add(btnClick);
            Controls.Add(textBox2);
            Controls.Add(textBox1);
            Name = "LabelMsg";
            Text = "Form1";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private TextBox textBox1;
        private TextBox textBox2;
        private Button btnClick;
        private Label lblMsg;
    }
}
