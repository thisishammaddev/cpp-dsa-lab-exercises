namespace lblProject
{
    public partial class LabelMsg : Form
    {
        public LabelMsg()
        {
            InitializeComponent();
        }
        private void Form1_Load(object sender, EventArgs e)
        {
            textBox1.Text = "OOP";
            textBox2.Focus();
        }
        private void textBox1_TextChanged(object sender, EventArgs e)
        {
           
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void btnClick_Click(object sender, EventArgs e)
        {
            lblMsg.Text = "Textbox 1: " + textBox1.Text + "\tTextbox 2: " + textBox2.Text;
            lblMsg.Visible = true;
            textBox1.Clear();
            textBox2.Clear();
            textBox2.Focus();
        }

        private void lblMsg_Click(object sender, EventArgs e)
        {

        }
    }
}
