﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Polymorphism
{
    //Polymorphism
    // 1 - Static Polymorphism = Method or Function Overloading & Operator Overloading
    class Calc
    {
        public string str;
        public int id;
        //Operator Overloading
        public static Calc operator +(Calc a, Calc b)
        {
            Calc c = new Calc();
            c.str = a.str + " " + b.str;
            c.id = a.id + b.id;
            return c;
        }



        //Method Overloading
        //public void Add()
        //{
        //    int a = 30;
        //    int b = 20;
        //    int c = a + b;
        //    Console.WriteLine(c);
        //}
        //public void Add(int a, int b)
        //{
        //    int c = a + b;
        //    Console.WriteLine(c);
        //}
        //public void Add(string a, string b)
        //{
        //    string c = a + " " + b;
        //    Console.WriteLine(c);
        //}
        //public void Add(float a, float b)
        //{
        //    float c = a + b;
        //    Console.WriteLine(c);
        //}
    }
    internal class Program
    {
        static void Main(string[] args)
        {
            Calc c1 = new Calc();
            //Operator Overloading
            c1.str = "Hassan";
            c1.id = 123;
            Calc c2 = new Calc();
            c2.str = "Shah";
            c2.id = 456;
            Calc c3 = new Calc();
            c3 = c1 + c2;
            Console.WriteLine(c3.str);
            Console.WriteLine(c3.id);
            //Method Overloading
            //c.Add();
            //c.Add(13, 45);
            //c.Add("Ali", "Hassan");
            //c.Add(3.4F, 5.4F);
            Console.ReadLine();
        }
    }
}
