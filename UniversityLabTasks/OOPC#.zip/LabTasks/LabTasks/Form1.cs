namespace LabTasks
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button13_Click(object sender, EventArgs e)
        {
            tempConversion a = new tempConversion();
            a.Show();
        }
    }
}
