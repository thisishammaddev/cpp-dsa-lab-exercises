﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LabTasks
{
    public partial class tempConversion : Form
    {
        public double UsInput;
        public double UsOutput;
        public tempConversion()
        {
            InitializeComponent();
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {


        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            UsInput = Convert.ToDouble(userInput.Text);
            UsOutput = UsInput - 32;
            UsOutput = UsOutput * 52;
            output.Text = UsOutput.ToString();
            output.Visible = true;
        }
    }
    
}

