﻿namespace LabTasks
{
    partial class tempConversion
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            userInput = new TextBox();
            textBox2 = new TextBox();
            button1 = new Button();
            output = new TextBox();
            SuspendLayout();
            // 
            // userInput
            // 
            userInput.Location = new Point(12, 94);
            userInput.Multiline = true;
            userInput.Name = "userInput";
            userInput.Size = new Size(422, 52);
            userInput.TabIndex = 0;
            userInput.Text = "Enter the first Input..";
            userInput.TextChanged += textBox1_TextChanged;
            // 
            // textBox2
            // 
            textBox2.BackColor = SystemColors.InactiveCaption;
            textBox2.Font = new Font("Segoe Print", 15.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            textBox2.ForeColor = SystemColors.InactiveCaptionText;
            textBox2.Location = new Point(-3, -3);
            textBox2.Multiline = true;
            textBox2.Name = "textBox2";
            textBox2.Size = new Size(451, 79);
            textBox2.TabIndex = 1;
            textBox2.Text = "Enter Temprature in farenhite to convert to Celcius";
            textBox2.TextChanged += textBox2_TextChanged;
            // 
            // button1
            // 
            button1.BackColor = SystemColors.HotTrack;
            button1.Font = new Font("Times New Roman", 18F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point, 0);
            button1.ForeColor = SystemColors.ButtonHighlight;
            button1.Location = new Point(108, 164);
            button1.Name = "button1";
            button1.Size = new Size(199, 44);
            button1.TabIndex = 2;
            button1.Text = "Convert";
            button1.UseVisualStyleBackColor = false;
            button1.Click += button1_Click;
            // 
            // output
            // 
            output.Location = new Point(99, 230);
            output.Multiline = true;
            output.Name = "output";
            output.Size = new Size(218, 43);
            output.TabIndex = 0;
            output.Text = "Output";
            output.TextChanged += textBox1_TextChanged;
            // 
            // tempConversion
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(446, 450);
            Controls.Add(button1);
            Controls.Add(textBox2);
            Controls.Add(output);
            Controls.Add(userInput);
            Name = "tempConversion";
            Text = "tempConversion";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private TextBox userInput;
        private TextBox textBox2;
        private Button button1;
        private TextBox output;
    }
}