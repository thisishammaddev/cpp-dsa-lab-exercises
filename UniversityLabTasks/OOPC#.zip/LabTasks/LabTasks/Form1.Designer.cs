﻿namespace LabTasks
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            textBox1 = new TextBox();
            button1 = new Button();
            button2 = new Button();
            button3 = new Button();
            button4 = new Button();
            button5 = new Button();
            button6 = new Button();
            button7 = new Button();
            button8 = new Button();
            button9 = new Button();
            button10 = new Button();
            button11 = new Button();
            button12 = new Button();
            button13 = new Button();
            button14 = new Button();
            button15 = new Button();
            button16 = new Button();
            SuspendLayout();
            // 
            // textBox1
            // 
            textBox1.Font = new Font("Segoe UI", 20F);
            textBox1.Location = new Point(2, 12);
            textBox1.Multiline = true;
            textBox1.Name = "textBox1";
            textBox1.Size = new Size(382, 55);
            textBox1.TabIndex = 0;
            textBox1.Text = "Enter Inputs.....";
            // 
            // button1
            // 
            button1.AutoSize = true;
            button1.BackColor = SystemColors.ActiveBorder;
            button1.Font = new Font("Times New Roman", 24F, FontStyle.Bold, GraphicsUnit.Point, 0);
            button1.ForeColor = SystemColors.ActiveCaptionText;
            button1.Location = new Point(2, 91);
            button1.Name = "button1";
            button1.Size = new Size(87, 79);
            button1.TabIndex = 1;
            button1.Text = "1";
            button1.UseVisualStyleBackColor = false;
            // 
            // button2
            // 
            button2.BackColor = SystemColors.ActiveBorder;
            button2.Font = new Font("Times New Roman", 24F, FontStyle.Bold);
            button2.ForeColor = SystemColors.ActiveCaptionText;
            button2.Location = new Point(95, 91);
            button2.Name = "button2";
            button2.Size = new Size(90, 79);
            button2.TabIndex = 1;
            button2.Text = "2";
            button2.UseVisualStyleBackColor = false;
            // 
            // button3
            // 
            button3.BackColor = SystemColors.ActiveBorder;
            button3.Font = new Font("Times New Roman", 24F, FontStyle.Bold);
            button3.ForeColor = SystemColors.ActiveCaptionText;
            button3.Location = new Point(191, 91);
            button3.Name = "button3";
            button3.Size = new Size(92, 79);
            button3.TabIndex = 2;
            button3.Text = "3";
            button3.UseVisualStyleBackColor = false;
            // 
            // button4
            // 
            button4.BackColor = SystemColors.ActiveBorder;
            button4.Font = new Font("Times New Roman", 24F, FontStyle.Bold);
            button4.ForeColor = SystemColors.ActiveCaptionText;
            button4.Location = new Point(289, 91);
            button4.Name = "button4";
            button4.Size = new Size(95, 79);
            button4.TabIndex = 3;
            button4.Text = "/";
            button4.UseVisualStyleBackColor = false;
            // 
            // button5
            // 
            button5.BackColor = SystemColors.ActiveBorder;
            button5.Font = new Font("Times New Roman", 24F, FontStyle.Bold);
            button5.Location = new Point(289, 176);
            button5.Name = "button5";
            button5.Size = new Size(95, 79);
            button5.TabIndex = 7;
            button5.Text = "*";
            button5.UseVisualStyleBackColor = false;
            // 
            // button6
            // 
            button6.BackColor = SystemColors.ActiveBorder;
            button6.Font = new Font("Times New Roman", 24F, FontStyle.Bold);
            button6.Location = new Point(191, 176);
            button6.Name = "button6";
            button6.Size = new Size(92, 79);
            button6.TabIndex = 6;
            button6.Text = "6";
            button6.UseVisualStyleBackColor = false;
            // 
            // button7
            // 
            button7.BackColor = SystemColors.ActiveBorder;
            button7.Font = new Font("Times New Roman", 24F, FontStyle.Bold);
            button7.ForeColor = SystemColors.ActiveCaptionText;
            button7.Location = new Point(95, 176);
            button7.Name = "button7";
            button7.Size = new Size(90, 79);
            button7.TabIndex = 4;
            button7.Text = "5";
            button7.UseVisualStyleBackColor = false;
            // 
            // button8
            // 
            button8.BackColor = SystemColors.ActiveBorder;
            button8.Font = new Font("Times New Roman", 24F, FontStyle.Bold);
            button8.ForeColor = SystemColors.ActiveCaptionText;
            button8.Location = new Point(2, 176);
            button8.Name = "button8";
            button8.Size = new Size(87, 79);
            button8.TabIndex = 5;
            button8.Text = "4";
            button8.UseVisualStyleBackColor = false;
            // 
            // button9
            // 
            button9.BackColor = SystemColors.ActiveBorder;
            button9.Font = new Font("Times New Roman", 24F, FontStyle.Bold);
            button9.ForeColor = SystemColors.ActiveCaptionText;
            button9.Location = new Point(289, 261);
            button9.Name = "button9";
            button9.Size = new Size(95, 79);
            button9.TabIndex = 11;
            button9.Text = "+";
            button9.UseVisualStyleBackColor = false;
            // 
            // button10
            // 
            button10.BackColor = SystemColors.ActiveBorder;
            button10.Font = new Font("Times New Roman", 24F, FontStyle.Bold);
            button10.ForeColor = SystemColors.ActiveCaptionText;
            button10.Location = new Point(191, 261);
            button10.Name = "button10";
            button10.Size = new Size(92, 79);
            button10.TabIndex = 10;
            button10.Text = "9";
            button10.UseVisualStyleBackColor = false;
            // 
            // button11
            // 
            button11.BackColor = SystemColors.ActiveBorder;
            button11.Font = new Font("Times New Roman", 24F, FontStyle.Bold);
            button11.ForeColor = SystemColors.ActiveCaptionText;
            button11.Location = new Point(95, 261);
            button11.Name = "button11";
            button11.Size = new Size(90, 79);
            button11.TabIndex = 8;
            button11.Text = "8";
            button11.UseVisualStyleBackColor = false;
            // 
            // button12
            // 
            button12.BackColor = SystemColors.ActiveBorder;
            button12.Font = new Font("Times New Roman", 24F, FontStyle.Bold);
            button12.Location = new Point(2, 261);
            button12.Name = "button12";
            button12.Size = new Size(87, 79);
            button12.TabIndex = 9;
            button12.Text = "7";
            button12.UseVisualStyleBackColor = false;
            // 
            // button13
            // 
            button13.BackColor = SystemColors.ActiveBorder;
            button13.Font = new Font("Times New Roman", 24F, FontStyle.Bold);
            button13.ForeColor = SystemColors.ActiveCaptionText;
            button13.Location = new Point(289, 346);
            button13.Name = "button13";
            button13.Size = new Size(95, 79);
            button13.TabIndex = 15;
            button13.Text = "-";
            button13.UseVisualStyleBackColor = false;
            button13.Click += button13_Click;
            // 
            // button14
            // 
            button14.BackColor = SystemColors.ActiveBorder;
            button14.Font = new Font("Times New Roman", 24F, FontStyle.Bold);
            button14.ForeColor = SystemColors.ActiveCaptionText;
            button14.Location = new Point(191, 346);
            button14.Name = "button14";
            button14.Size = new Size(92, 79);
            button14.TabIndex = 14;
            button14.Text = ".";
            button14.UseVisualStyleBackColor = false;
            // 
            // button15
            // 
            button15.BackColor = SystemColors.ActiveBorder;
            button15.Font = new Font("Times New Roman", 24F, FontStyle.Bold);
            button15.ForeColor = SystemColors.ActiveCaptionText;
            button15.Location = new Point(95, 346);
            button15.Name = "button15";
            button15.Size = new Size(90, 79);
            button15.TabIndex = 12;
            button15.Text = "=";
            button15.UseVisualStyleBackColor = false;
            // 
            // button16
            // 
            button16.BackColor = SystemColors.ActiveBorder;
            button16.Font = new Font("Times New Roman", 24F, FontStyle.Bold);
            button16.ForeColor = SystemColors.ActiveCaptionText;
            button16.Location = new Point(2, 346);
            button16.Name = "button16";
            button16.Size = new Size(87, 79);
            button16.TabIndex = 13;
            button16.Text = "0";
            button16.UseVisualStyleBackColor = false;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(386, 430);
            Controls.Add(button13);
            Controls.Add(button14);
            Controls.Add(button15);
            Controls.Add(button16);
            Controls.Add(button9);
            Controls.Add(button10);
            Controls.Add(button11);
            Controls.Add(button12);
            Controls.Add(button5);
            Controls.Add(button6);
            Controls.Add(button7);
            Controls.Add(button8);
            Controls.Add(button4);
            Controls.Add(button3);
            Controls.Add(button2);
            Controls.Add(button1);
            Controls.Add(textBox1);
            Name = "Form1";
            Text = "Calculator";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private TextBox textBox1;
        private Button button1;
        private Button button2;
        private Button button3;
        private Button button4;
        private Button button5;
        private Button button6;
        private Button button7;
        private Button button8;
        private Button button9;
        private Button button10;
        private Button button11;
        private Button button12;
        private Button button13;
        private Button button14;
        private Button button15;
        private Button button16;
    }
}
