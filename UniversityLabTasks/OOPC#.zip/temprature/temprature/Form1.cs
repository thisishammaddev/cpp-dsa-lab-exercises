namespace temprature
{
    public partial class Form1 : Form
    {
        public double tempFare;
        public double tempCel;
        public Form1()
        {
            InitializeComponent();
        }

        private void btnConvert_Click(object sender, EventArgs e)
        {
            if (double.TryParse(textBox1.Text, out tempFare))
            {
                tempCel = (5.0 / 9.0) * (tempFare - 32);
                textBox2.Text = tempCel.ToString();
                textBox2.Visible = true;
            }
            else
            {
                MessageBox.Show("Please enter a valid temperature in Fahrenheit.");
            }
        }


        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
