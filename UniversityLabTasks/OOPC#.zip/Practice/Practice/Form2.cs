﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Practice
{
    public partial class Form2 : Form
    {
        public static Form2 instance;
        public Label lbl;
        public Form2()
        {
            InitializeComponent();
            instance = this;
            lbl = label1;
        }

        private void Form2_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            Form1.Form1instance.tbx.Text = "Hello from Form 2";
        }
    }
}
