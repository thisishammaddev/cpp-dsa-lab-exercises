namespace Practice
{
    public partial class Form1 : Form
    {
        public static Form1 Form1instance;
        public TextBox tbx;
        public TextBox tbx1;
        public Form1()
        {
            InitializeComponent();
            Form1instance = this;
            tbx = textBox1;
            tbx1 = textBox2;
        }

        private void btnClick_Click(object sender, EventArgs e)
        {
            //comboBox1.SelectedItem = null;
            //MessageBox.Show(comboBox1.SelectedItem.ToString());
            MessageBox.Show("Button Was clicked");
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void btnNext_Click(object sender, EventArgs e)
        {
            Form2 f2 = new Form2();
            f2.Show();
        }

        private void btn1_Click(object sender, EventArgs e)
        {
            Form2.instance.lbl.Text = textBox1.Text;
        }

        private void btnNext3_Click(object sender, EventArgs e)
        {
            Form3 f3 = new Form3();
            f3.Show();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Form3.form3Instance.lbl3.Text = textBox2.Text;
        }
    }
}
