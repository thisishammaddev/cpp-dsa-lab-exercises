﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Practice
{
    public partial class Form3 : Form
    {
        public static Form3 form3Instance;
        public Label lbl3;
        public Form3()
        {
            InitializeComponent();
            form3Instance = this;
            lbl3 = label1;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Form1.Form1instance.tbx1.Text = "Data Transfer from FORM 3!";
        }
    }
}
