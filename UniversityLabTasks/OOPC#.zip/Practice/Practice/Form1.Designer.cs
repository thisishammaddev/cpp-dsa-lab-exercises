﻿namespace Practice
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            comboBox1 = new ComboBox();
            btnClick = new Button();
            textBox1 = new TextBox();
            btnNext = new Button();
            btn1 = new Button();
            textBox2 = new TextBox();
            button1 = new Button();
            btnNext3 = new Button();
            SuspendLayout();
            // 
            // comboBox1
            // 
            comboBox1.FormattingEnabled = true;
            comboBox1.Items.AddRange(new object[] { "Pak", "Ind", "Aus", "Nz", "Sa", "WI", "Zim", "SriL", "Afgh", "Nep" });
            comboBox1.Location = new Point(170, 12);
            comboBox1.Name = "comboBox1";
            comboBox1.Size = new Size(220, 23);
            comboBox1.TabIndex = 0;
            comboBox1.Text = "Select Country";
            comboBox1.SelectedIndexChanged += comboBox1_SelectedIndexChanged;
            // 
            // btnClick
            // 
            btnClick.Location = new Point(396, 12);
            btnClick.Name = "btnClick";
            btnClick.Size = new Size(94, 27);
            btnClick.TabIndex = 1;
            btnClick.Text = "click";
            btnClick.UseVisualStyleBackColor = true;
            btnClick.Click += btnClick_Click;
            // 
            // textBox1
            // 
            textBox1.Location = new Point(50, 82);
            textBox1.Name = "textBox1";
            textBox1.Size = new Size(196, 23);
            textBox1.TabIndex = 2;
            // 
            // btnNext
            // 
            btnNext.Location = new Point(170, 130);
            btnNext.Name = "btnNext";
            btnNext.Size = new Size(151, 25);
            btnNext.TabIndex = 4;
            btnNext.Text = "Open Next Form 2";
            btnNext.UseVisualStyleBackColor = true;
            btnNext.Click += btnNext_Click;
            // 
            // btn1
            // 
            btn1.Location = new Point(296, 82);
            btn1.Name = "btn1";
            btn1.Size = new Size(194, 24);
            btn1.TabIndex = 5;
            btn1.Text = "Click to open the label in Form 2";
            btn1.UseVisualStyleBackColor = true;
            btn1.Click += btn1_Click;
            // 
            // textBox2
            // 
            textBox2.Location = new Point(26, 199);
            textBox2.Multiline = true;
            textBox2.Name = "textBox2";
            textBox2.Size = new Size(220, 28);
            textBox2.TabIndex = 6;
            // 
            // button1
            // 
            button1.Location = new Point(296, 199);
            button1.Name = "button1";
            button1.Size = new Size(214, 28);
            button1.TabIndex = 7;
            button1.Text = "Click to edit the label in form 3";
            button1.UseVisualStyleBackColor = true;
            button1.Click += button1_Click;
            // 
            // btnNext3
            // 
            btnNext3.Location = new Point(170, 262);
            btnNext3.Name = "btnNext3";
            btnNext3.Size = new Size(220, 36);
            btnNext3.TabIndex = 8;
            btnNext3.Text = "Click to Open Form 3";
            btnNext3.UseVisualStyleBackColor = true;
            btnNext3.Click += btnNext3_Click;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(584, 391);
            Controls.Add(btnNext3);
            Controls.Add(button1);
            Controls.Add(textBox2);
            Controls.Add(btn1);
            Controls.Add(btnNext);
            Controls.Add(textBox1);
            Controls.Add(btnClick);
            Controls.Add(comboBox1);
            Name = "Form1";
            Text = "Form1";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private ComboBox comboBox1;
        private Button btnClick;
        private TextBox textBox1;
        private Button btnNext;
        private Button btn1;
        private TextBox textBox2;
        private Button button1;
        private Button btnNext3;
    }
}
