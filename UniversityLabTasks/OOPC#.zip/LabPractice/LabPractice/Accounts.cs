﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
namespace lab_8
{
    abstract class account
    {
        protected string accounttitle;
        protected double balance;
        protected int accounttype;
        public abstract void Deposit();
        public abstract double Withdraw();
    }

    class SavingAccount : account
    {
        public SavingAccount()
        {
            accounttitle = "Meezan Bank";
            accounttype = 1;
        }
        public override void Deposit()
        {
            Console.WriteLine("The Account Title is " + accounttitle);
            Console.WriteLine("Enter Balance");
            balance = Convert.ToDouble(Console.ReadLine());
            if (balance > 100)
            {
                balance += 0.01 * balance;
                Console.WriteLine("The User gives bonus: " + balance);
            }
            Console.WriteLine("The Account Type is " + accounttype);
        }

        public override double Withdraw()
        {
            Console.WriteLine("***************************************************");
            Console.WriteLine("Enter the amount to withdraw: ");
            double amount = Convert.ToDouble(Console.ReadLine());
            Console.WriteLine("***********Succesfully Withdraw :-) ****************");
            if (amount > balance)
            {
                Console.WriteLine("Insufficient balance.");
                return 0;
            }
            balance -= amount;
            Console.WriteLine("Remainig balance " + balance);
            return amount;
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            List<account> accounts = new List<account>();
            account acc = new SavingAccount();
            acc.Deposit();
            acc.Withdraw();
            accounts.Add(acc);

        }
    }
}