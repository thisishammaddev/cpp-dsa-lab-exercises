﻿//using System;
//using System.Collections.Generic;
//using System.Linq;
//using System.Text;
//using System.Threading.Tasks;

//namespace LabPractice
//{
//    abstract class Shape
//    {
//        public void ShapeName(string name)
//        {
//            Console.WriteLine(name);
//        }
//        public abstract string ReturnShapeName();
//        public abstract double Area();
//    }
//    class Square : Shape
//    {
//        public double sideofSquares;
//        public Square(double sideofSquares)
//        {
//            this.sideofSquares = sideofSquares;
//        }
//        public override string ReturnShapeName()
//        {
//            return "It is a square";
//        }
//        public override double Area()
//        {
//            return sideofSquares * sideofSquares;
//        }
//    }
//    class Triangle : Shape
//    {
//        int a, b, c, calc;
//        public Triangle(int a, int b, int c)
//        {
//            this.a = a;
//            this.b = b;
//            this.c = c;
//        }
//        public override string ReturnShapeName()
//        {
//            return "It is a Triangle";

//        }
//        public override double Area()
//        {
//            calc = (a + b + c) / 2;
//            return Math.Sqrt(calc * (calc - a) * (calc - b) * (calc - c));
//        }
//    }
//    internal class Program
//    {
//        static void Main(string[] args)
//        {
//            Console.WriteLine("Shapes");
//            List<Shape> shapes = new List<Shape>();
//            Shape s1 = new Square(30);
//            Shape s2 = new Triangle(67, 90, 56);
//            shapes.Add(s1);
//            shapes.Add(s2);
//            Shape s3 = new Square(45);
//            Shape s4 = new Triangle(89, 23, 78);
//            shapes.Add(s3);
//            shapes.Add(s4);
//            foreach (Shape s in shapes)
//            {
//                Console.WriteLine(s.ReturnShapeName() + " Area = " + s.Area());
//            }
//        }
//    }
//}
