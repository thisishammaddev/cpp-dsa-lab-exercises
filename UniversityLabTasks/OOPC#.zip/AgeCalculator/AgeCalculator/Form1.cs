using Microsoft.VisualBasic;
using System.Linq.Expressions;

namespace AgeCalculator
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnCalculate_Click(object sender, EventArgs e)
        {
            try
            {
                if (dtpCurrentDate.Value < dtpDOB.Value)
                {
                    MessageBox.Show("Current Date must be greate than the DOB!");
                }
                int Age = dtpCurrentDate.Value.Year - dtpDOB.Value.Year;
                if (dtpDOB.Value.AddYears(Age) > dtpDOB.Value)
                    Age--;
                lblAge.Text = "Your Age is: " + Age.ToString();
            }
            catch(Exception err)
            {
                MessageBox.Show(err.Message, "Error Occured!!!");
            }
        }
    }
}
