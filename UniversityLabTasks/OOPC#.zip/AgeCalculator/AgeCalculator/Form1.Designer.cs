﻿namespace AgeCalculator
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            dtpDOB = new DateTimePicker();
            btnCalculate = new Button();
            label2 = new Label();
            dtpCurrentDate = new DateTimePicker();
            lblAge = new Label();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 15.75F);
            label1.Location = new Point(71, 72);
            label1.Name = "label1";
            label1.Size = new Size(131, 30);
            label1.TabIndex = 0;
            label1.Text = "Date of birth";
            // 
            // dtpDOB
            // 
            dtpDOB.CustomFormat = "dd-MMM-yyyy";
            dtpDOB.Font = new Font("Segoe UI", 15.75F);
            dtpDOB.Format = DateTimePickerFormat.Custom;
            dtpDOB.Location = new Point(257, 67);
            dtpDOB.Name = "dtpDOB";
            dtpDOB.Size = new Size(200, 35);
            dtpDOB.TabIndex = 2;
            dtpDOB.Tag = "";
            // 
            // btnCalculate
            // 
            btnCalculate.Font = new Font("Segoe UI", 15.75F);
            btnCalculate.Location = new Point(336, 245);
            btnCalculate.Name = "btnCalculate";
            btnCalculate.Size = new Size(121, 38);
            btnCalculate.TabIndex = 3;
            btnCalculate.Text = "Calculate";
            btnCalculate.UseVisualStyleBackColor = true;
            btnCalculate.Click += btnCalculate_Click;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Segoe UI", 15.75F);
            label2.Location = new Point(70, 156);
            label2.Name = "label2";
            label2.Size = new Size(132, 30);
            label2.TabIndex = 0;
            label2.Text = "Current Date";
            // 
            // dtpCurrentDate
            // 
            dtpCurrentDate.CustomFormat = "dd-MMM-yyyy";
            dtpCurrentDate.Font = new Font("Segoe UI", 15.75F);
            dtpCurrentDate.Format = DateTimePickerFormat.Custom;
            dtpCurrentDate.Location = new Point(257, 151);
            dtpCurrentDate.Name = "dtpCurrentDate";
            dtpCurrentDate.Size = new Size(200, 35);
            dtpCurrentDate.TabIndex = 2;
            // 
            // lblAge
            // 
            lblAge.AutoSize = true;
            lblAge.Location = new Point(71, 261);
            lblAge.Name = "lblAge";
            lblAge.Size = new Size(67, 15);
            lblAge.TabIndex = 0;
            lblAge.Text = "Your Age: 0";
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(510, 450);
            Controls.Add(btnCalculate);
            Controls.Add(dtpCurrentDate);
            Controls.Add(dtpDOB);
            Controls.Add(lblAge);
            Controls.Add(label2);
            Controls.Add(label1);
            Name = "Form1";
            Text = "Age Calculator";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private DateTimePicker dtpDOB;
        private Button btnCalculate;
        private Label label2;
        private DateTimePicker dtpCurrentDate;
        private Label lblAge;
    }
}
