﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OOP_Practice
{
    internal class Program
    {
        class Student
        {
            string name;
            int roll;
            double gpa;
            char grade;
            string dept;
            public Student(string name, int roll, double gpa, char grade, string dept)
            {
                this.name = name;
                this.roll = roll;
                this.gpa = gpa;
                this.grade = grade;
                this.dept = dept;
            }
            public void Display()
            {
                Console.WriteLine("Name: " + name + "roll number: " + roll + " Has a gpa of : " + gpa + " Grade: " + grade + " Department:" + dept);
            }
        }
        static void Main(string[] args)
        {
            Student st = new Student("ELON", 123, 3.4F, 'A', "CSE");
            st.Display();
            Console.Read();
        }
    }
}
